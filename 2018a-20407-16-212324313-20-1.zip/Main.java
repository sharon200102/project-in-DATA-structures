import java.util.Arrays;
import java.util.Random;
import java.lang.Math;

/**
 *Main Program
 */

public class Main
{
    /**
     * This method fills an array with random values
     *
     * @param  array  the array to fill
     * 
     * Time Complexity is O(n)
     */
    public static void RandomArray(double[] array){
        Random randomize = new Random();
        double rangeMin=0;
        double rangeMax=1023;
        //going through the array and randomizing its values
        for (int x=0; x<array.length ; x++){
            array[x] = rangeMin + (rangeMax - rangeMin) * randomize.nextDouble();
        }
    }
   /**
     * This method finds the medians in the points n/4 n/2 and 3n/4 of the array
     *
     * @param  array  the array to find its medians
     * 
     * Time Complexity is O(nlog(n))
     */
    public static void FindMedian(double[] array){
        //creating new median item.
        median MedianFinder= new median(array.length);
        //going through the array and inserting its items to the median item, in the check points we print the median.
        for(int x=0; x<array.length ; x++){
            MedianFinder.insert(array[x]);
            if(x==array.length/4) {
                System.out.print("  The median at the n/4 checkpoint is:");
                MedianFinder.printMedian(); 
            }
            if(x==array.length/2) {
                System.out.print("  The median at the n/2 checkpoint is:");
                MedianFinder.printMedian(); 
            }
            if(x==array.length*3/4) {
                System.out.print("  The median at the 3n/4 checkpoint is:");
                MedianFinder.printMedian(); 
            }
        }
        System.out.print("  The median at the n checkpoint is:");
        MedianFinder.printMedian(); 
    }
   /**
     * This is the main method of the program
     * 
     * Time complexity is O(log(n))
     */
    public static void main(String[] args){
        //creating 3 arrays
        double[] array1 = new double[800];
        double[] array2 = new double[400];
        double[] array3 = new double[200];
        //filling the arrays with random integers
        RandomArray(array1);
        RandomArray(array2);
        RandomArray(array3);
        //finding the medians
        System.out.println("The arrays medians are:");
        System.out.println("-First Array Medians:");
        FindMedian(array1);
        System.out.println("-Second Array Medians:");
        FindMedian(array2);
        System.out.println("-Third Array Medians:");
        FindMedian(array3);

    }
}