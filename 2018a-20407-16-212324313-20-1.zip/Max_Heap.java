/**
 *  Java Program to Implement Heap
 */
 
import java.util.Scanner;
 
/** Class Heap */
class Max_Heap
{
 
    protected double[] heapArray;
    /** size of array **/
    protected int maxSize; 
    /** number of nodes in array **/
    protected int heapSize; 
 
    /** Constructor for objects of class Max_Heap 
     *  time complexity O(1)
     * place complexity O(n)**/
    public Max_Heap(int mx) 
    {
        maxSize = mx;
        heapSize = 0;
        heapArray = new double[maxSize]; 
    }
    /** Check if heap is empty 
     *  Input: there is no input
     *  Output: the function returns true if heapSize is 0 and false if not
     *  time complexity O(1)
     * place complexity O(1)
     */
    public boolean isEmpty() 
    {
        return heapSize == 0;
    }
    /** Function to insert element while saving the Max_heap structure
     * Input: the number that you want to insert to Max_Heap
     * Output: if the number  was added successfully, the function will return true and false if not
     * time complexity O(log(n)
     * place complexity O(1)
     */
    public boolean insert(double ele) 
    {
        if (heapSize + 1 == maxSize)
            return false;
        heapArray[++heapSize] = ele;
        int pos = heapSize;
        while (pos != 1 && ele > heapArray[pos/2])
        {
            heapArray[pos] = heapArray[pos/2];
            pos /=2;
        }
        heapArray[pos] = ele;    
        return true;
    } 
 
    /** Function to remove the root  while saving the Max_heap structure
     *  Input: there is no input
     *  Output: the function returns the value of the root
     * time complexity O(log(n)
     * place complexity O(1)
     */
    public double remove()
    {
        int parent, child;
        double item, temp;
        if (isEmpty() )
            throw new RuntimeException("Error : Heap empty!");
 
        item = heapArray[1];
        temp = heapArray[heapSize--];
 
        parent = 1;
        child = 2;
        while (child <= heapSize)
        {
            if (child < heapSize && heapArray[child] < heapArray[child + 1])
                child++;
            if (temp >= heapArray[child])
                break;
 
            heapArray[parent] = heapArray[child];
            parent = child;
            child *= 2;
        }
        heapArray[parent] = temp;
 
        return item;
    }
     /**
     *  Input: there is no input
     *  Output: the function returns the value of the root without removing it
     *  time complexity O(1)
     * place complexity O(1)
     */
    public double get_Max()
    {
        return heapArray[1];
    }
}