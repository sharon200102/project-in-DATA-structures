

public class median
{
    
    private Min_Heap min;
    private Max_Heap max;
    private int Max_Place; // the number of noeds in each heap
    

    /**
     * Constructor for objects of class median
     *  time complexity O(1)
     * place complexity O(n)
     */
    public median(int Max_Place)
    {
        this.Max_Place=Max_Place;
        min=new Min_Heap(Max_Place);
        max=new Max_Heap(Max_Place);
        
    }
    /** Function to insert element to the structure in a way that will enable to return the median in O(1) time complexity
     * Input: the numner that you want to insert to median
     * Output: there is no output
     * time complexity O(log(n))
     * place complexity O(1)
     */
    public void  insert(double x)
    { 
        boolean check=false ;
        if((this.min.heapSize==0)&&(this.max.heapSize==0))  // If both of the heaps are empty
        {
           
            min.insert(x);
            check=true;
        }
        if((min.heapSize==1)&&(max.heapSize==0)&&(check==false)) // If there is only one number in the median
        {
            double y=min.remove();
            if(x>y)
            {
                min.insert(x);
                max.insert(y);
                
            }
            else
            {
                 max.insert(x);
                 min.insert(y);
                 
            }
            check=true;
            
        }
        if(check==false) // The general case
        {
            if(x<max.get_Max())
            {
            max.insert(x);
            }
            else
            {
                min.insert(x);
            }
            if(max.heapSize>=min.heapSize+2)
            {
                min.insert(max.remove());
            }
            if(max.heapSize+2<=min.heapSize)
            {
                max.insert(min.remove());
            }
            
        }
        
        
        
      
        
        
    }
    /** Function that prints the median
     * *  time complexity O(1)
     * place complexity O(1)
     */
    
    public void printMedian()
    {
        if(max.heapSize==min.heapSize)
        {
            System.out.println(max.get_Max());
        }
        else
        {
        if((max.heapSize<min.heapSize))
        {
            System.out.println(min.get_Min());
        }
        if((max.heapSize>min.heapSize))
        {
            System.out.println(max.get_Max());
        }
    }
    }

   
}
